### PIV and DAC Tagged Files 
The PIV and DAC Tagged files can be found [here](https://drive.google.com/open?id=1juiPs7KFGGPGeaVHgUJweaxXIZzYwY2u)


PSA: POS_tagging.py is the main script. The other scripts were combined into this one.

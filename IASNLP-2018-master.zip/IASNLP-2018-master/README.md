# IASNLP-2018
A repository of all the assignments and their solutions given at IASNLP 2018. Use at your free will. 

The updated file is [here.](https://github.com/RishavR/IASNLP-2018/blob/master/Pivot_And_DigitChar_Pair_Tagger_Script/POS_tagging.py)
